<!-- La commande suivante ins�re le squelette de la page -->

<?php

     include("authenticateAdmin.inc.php");
     include("haut_page.inc.php");




//**************************************************************
// FONCTION DE REMPLISSAGE DE LA BOITE DE S�LECTION - BRASSEURS
//***************************************************************
function load_box_brasseur()
{

  //Connestion � la BD et ouverture de la table "Brasseurs"
  
	$connexion = mysql_connect(HOST,USER,PASS);
  	mysql_select_db(DB,$connexion);

  	$result = mysql_query("SELECT num_auto,nomBrasseur FROM brasseurs order by num_auto",$connexion) or die(mysql_error());

   // Affichage des r�sultats de la requ�te....
  while ($brasseur = mysql_fetch_array($result))
  {
		echo "<option value=".$brasseur[0]."\">".$brasseur[1]."</option>";	
  }

  mysql_free_result($result);
  mysql_close($connexion);

}
//***************************************************************

//**************************************************************
// FONCTION DE REMPLISSAGE DE LA BOITE DE S�LECTION - PRODUITS
//***************************************************************
function load_box_produits()
{

  //Connestion � la BD et ouverture de la table "Brasseurs"
  
	$connexion = mysql_connect(HOST,USER,PASS);
  	mysql_select_db(DB,$connexion);

	$query = "SELECT inventaire.num_auto, brasseurs.nomBrasseur, inventaire.nomBiere FROM brasseurs, inventaire WHERE inventaire.idBrasseur = brasseurs.num_auto ORDER 		  BY brasseurs.nomBrasseur";

  	$result = mysql_query($query,$connexion) or die(mysql_error());

   // Affichage des r�sultats de la requ�te....
  while ($produit = mysql_fetch_array($result))
  {
		echo "<option value=".$produit[0]."\">".$produit[1]." - ".$produit[2]."</option>";	
  }

  mysql_free_result($result);
  mysql_close($connexion);

}
//***************************************************************
  

$okAdmin = verifyAdmin();
if ($okAdmin == "true")
{

	include("FORM_AjoutSupprProduit.php");
}
else
{
	include("erreur.php");

}


?>







<!-- La commande suivante ins�re le bas de page -->
<?php include("bas_page.inc.php")?>
	