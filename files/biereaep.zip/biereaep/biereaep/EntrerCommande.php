<!-- La commande suivante ins�re le squelette de la page -->

<?php

     include("authenticateAdmin.inc.php");
     include("haut_page.inc.php");


//**************************************************************
// FONCTION DE REMPLISSAGE DU TABLEAu DE L'INVENTAIRE
//***************************************************************
function load_modif_inventaire()
{
	
	$cpt = 0;

  //Connestion � la BD et ouverture de la table "Inventaire"
  
	$connexion = mysql_connect(HOST,USER,PASS);
  	mysql_select_db(DB,$connexion);

	$query = "SELECT inventaire.num_auto, brasseurs.nomBrasseur, inventaire.nomBiere, inventaire.quantite FROM brasseurs, inventaire WHERE 					inventaire.idBrasseur = brasseurs.num_auto ORDER BY brasseurs.nomBrasseur, inventaire.nomBiere";

  	$result = mysql_query($query,$connexion) or die(mysql_error());


  	 // Affichage des r�sultats de la requ�te....
  	while ($inventaire = mysql_fetch_array($result))
 	{
		echo "<tr class=\"trClass\">";
		echo "<td>".$inventaire[1]."</td><td>".$inventaire[2]."</td>";	
		echo "<td><input name=\"qteArray[".$cpt."]\" type=\"text\" size=\"7\" value=\"0\">";
		echo "<input name=\"numArray[".$cpt."]\" type=\"hidden\" size=\"7\" value=".$inventaire[0]."></td>";
		echo "<input name=\"oldQteArray[".$cpt."]\" type=\"hidden\" size=\"7\" value=".$inventaire[3]."></td>";
		echo "</tr>";
		$cpt ++;
  	}

  	mysql_free_result($result);
 	mysql_close($connexion);


}

$okAdmin = verifyAdmin();
if ($okAdmin == "true")
{

	include("FORM_EntrerCommande.php");
}
else
{
	include("erreur.php");

}


?>
 

<!-- La commande suivante ins�re le bas de page -->
<?php include("bas_page.inc.php")?>
	




					
