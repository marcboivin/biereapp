<!-- La commande suivante ins�re le squelette de la page -->

<?php

     include("haut_page.inc.php");

	$total = 0;

	$comiteID = $_POST['comiteID'];
	$factureA = unserialize(urldecode($_POST['factureA']));
	$description = unserialize(urldecode($_POST['description']));

	$qteCommandeArray =  $_POST['qteCommandeArray'];


//**************************************************************
// FONCTION DE REMPLISSAGE DU TABLEAu R�CAPITULAIF - COMMANDE
//***************************************************************
function load_commande_finale()
{
	global $qteCommandeArray, $total;
	
	$cpt = 0;
	

	//V�rification pour les erreurs dans les quantit�s...
	while ($qteCommandeArray[$cpt] != "")
	{
		if( !is_numeric($qteCommandeArray[$cpt])) 
		{
			$erreur = true;
		}
		$cpt ++;

	}

	// V�rification termin�e, on remet le compteur � 0
	$cpt =0;
	$cpt2 = 0; // On utilise un deuxi�me compteur pour conserver seulement l'index des produits voulus pour le transfert � 
		   // la fonction finale (cr�ation de la facture et modification de l'inventaire.

	if($erreur != true)
	{
		
  		//Connexion � la BD et ouverture de la table "Inventaire"
  
		$connexion = mysql_connect(HOST,USER,PASS);
  		mysql_select_db(DB,$connexion);
	
		$query = "SELECT inventaire.num_auto, brasseurs.nomBrasseur, inventaire.nomBiere, inventaire.prix FROM brasseurs, inventaire WHERE inventaire.idBrasseur = 			brasseurs.num_auto ORDER BY brasseurs.nomBrasseur, inventaire.nomBiere";

  		$result = mysql_query($query,$connexion) or die(mysql_error());

		 // Affichage des r�sultats de la requ�te....
		
  		while ($inventaire = mysql_fetch_array($result))
 		{

		  if ($qteCommandeArray[$cpt] != 0)
		  {
			$sousTotal = $qteCommandeArray[$cpt] * $inventaire[3];
			$total += $sousTotal;

			echo "<tr class=\"trClass\">";
				
			   echo "<td>".$inventaire[1]."</td><td>".$inventaire[2]."</td>";
  			   echo "<td align=\"center\">".number_format($inventaire[3], 2, '.', "")."</td>";
			   echo "<td align=\"center\">".$qteCommandeArray[$cpt]."</td>";
			   echo "<td>".number_format($sousTotal, 2, '.', "")."$ 
				  <input name=\"numArray[".$cpt2."]\" type=\"hidden\" size=\"7\" value=".$inventaire[0].">
				  <input name=\"nbCommande[".$cpt2."]\" type=\"hidden\" size=\"7\" value=".$qteCommandeArray[$cpt].">
				</td>";
			
			echo "</tr>";
			$cpt2 ++;
		  }

		  $cpt ++;
		}

		
		mysql_free_result($result);
 		mysql_close($connexion);

  	}

	else
	{
		echo "<script>alert(\"Les quantit�s command�es doivent �tre des NOMBRES ENTIERS\")</script>";
		
	}

	

}

//**************************************************************
// Retourne le nom du comit�
//***************************************************************
function nom_comite()
{
	global $comiteID;
	
	 //Connextion � la BD et ouverture de la table "Comit�"
  
	$connexion = mysql_connect(HOST,USER,PASS);
  	mysql_select_db(DB,$connexion);

	$query = "SELECT nomComite FROM comites WHERE num_auto=".$comiteID.";";

  	$result = mysql_query($query,$connexion) or die(mysql_error());


  	 // Affichage des r�sultats de la requ�te....
  	while ($nomComite = mysql_fetch_array($result))
 	{
		echo $nomComite[0];
  	}

  	mysql_free_result($result);
 	mysql_close($connexion);

}


  
?>


 <table align="center" border="0" width="600">

	<tr> <td> <form enctype="multipart/form-data" action="processOrder.php" method="POST"> </td></tr>
	<tr><td align="center" colspan="2">
		<font size="4"> <b><i>FACTURATION</i></b></font><br>
		<img src="images/facturationEtape3.gif">
	</td></tr>
 

	<tr><td colspan="2">
		<b><i>Comit� :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </i></b><?php nom_comite(); ?><br>
		<b><i>Factur� � :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i></b><?php echo $factureA; ?><br>
		<b><i>Description :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i></b><?php echo $description; ?><br><br>
	</td></tr>

		
	 <tr><td colspan="2">
	  <table align="center" border="2" width="100%" bordercolor="black">

	  <tr bgcolor="black">
	    <td align="center"><font color="white"><b> Brasseur  </b></font></td>
	    <td align="center"><font color="white"><b> Nom </b></font></td>
	    <td align="center"><font color="white"><b> Prix ($) </b></font></td>
	    <td align="center"><font color="white"><b> Qt� Command�e </b></font></td>
	    <td align="center"><font color="white"><b> Sous-Total</b></font></td>
	  </tr>

	
	
	<?php 

		load_commande_finale(); 

	//On re-passe en param�tre les donn�es que l'on vient de recevoir...
	echo "<input name=\"comiteID\" type=\"hidden\" size=\"7\" value=".$comiteID.">";
	echo "<input name=\"factureA\" type=\"hidden\" size=\"7\" value=".urlencode(serialize($factureA)).">";
	echo "<input name=\"description\" type=\"hidden\" size=\"7\" value=".urlencode(serialize($description)).">";

	?>

	</table>
	</td></tr>


	<tr>
	   <td align="right"><b><i>Total : &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i></b></td>
	   <td><?php echo number_format($total, 2, '.', "") ?>$</td>

	</tr>
	<tr>
	   <td align="center">
		<input type="radio" name="compte" value="IMPUTER" checked>IMPUTER &nbsp;&nbsp;&nbsp;
		<input type="radio" name="compte" value="PAY�">PAY�&nbsp;&nbsp;&nbsp; 
		<input type="radio" name="compte" value="A_PAYER">� PAYER
	   </td>
	</tr>		
	<tr><td colspan="5"><center><input type="submit" value="Confirmer la commande!"> <br><hr></center>  </form> </td></tr>			

	
	
 </table>
 

<!-- La commande suivante ins�re le bas de page -->
<?php include("bas_page.inc.php")?>
	
