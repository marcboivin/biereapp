<!-- La commande suivante ins�re le squelette de la page -->

<?php

     include("haut_page.inc.php");

	$comiteID = $_POST['comiteID'];
	$factureA = $_POST['factureA'];
	$description = $_POST['description'];


//***************************************************************************
// FONCTION DE REMPLISSAGE DU TABLEAu DE L'INVENTAIRE - pour passer commande
//***************************************************************************
function load_inventaire_commande()
{
	
	$cpt = 0;

  //Connestion � la BD et ouverture de la table "Inventaire"
  
	$connexion = mysql_connect(HOST,USER,PASS);
  	mysql_select_db(DB,$connexion);

	$query = "SELECT inventaire.num_auto, brasseurs.nomBrasseur, inventaire.nomBiere, inventaire.prix, inventaire.quantite FROM brasseurs, inventaire WHERE 					inventaire.idBrasseur = brasseurs.num_auto ORDER BY brasseurs.nomBrasseur, inventaire.nomBiere";

  	$result = mysql_query($query,$connexion) or die(mysql_error());


  	 // Affichage des r�sultats de la requ�te....
  	while ($inventaire = mysql_fetch_array($result))
 	{
		echo "<tr class=\"trClass\">";
		echo "<td>".$inventaire[1]."</td><td>".$inventaire[2]."</td><td align=\"right\">".number_format($inventaire[3], 2, '.', "")."</td><td align=\"center\">".$inventaire[4]."</td>";	
		echo "<td align=\"center\"><input name=\"qteCommandeArray[".$cpt."]\" type=\"text\" size=\"7\" value=\"0\"></td>";
		echo "</tr>";

		$cpt ++;
  	}
  	mysql_free_result($result);
 	mysql_close($connexion);

}


//**************************************************************
// Retourne le nom du comit� 
//***************************************************************
function nom_comite()
{
	global $comiteID;
	
	 //Connestion � la BD et ouverture de la table "Inventaire"
  
	$connexion = mysql_connect(HOST,USER,PASS);
  	mysql_select_db(DB,$connexion);

	$query = "SELECT nomComite FROM comites WHERE num_auto=".$comiteID.";";

  	$result = mysql_query($query,$connexion) or die(mysql_error());


  	 // Affichage des r�sultats de la requ�te....
  	while ($nomComite = mysql_fetch_array($result))
 	{
		echo $nomComite[0];
  	}

  	mysql_free_result($result);
 	mysql_close($connexion);

}
//***************************************************************

  
?>


 <table align="center" border="0" width="600">

	<tr> <td> <form enctype="multipart/form-data" action="factureCommande3.php" method="POST"> </td></tr>
	<tr><td align="center" colspan="5">
		<font size="4"> <b><i>FACTURATION</i></b></font><br>
		<img src="images/facturationEtape2.gif">
	</td></tr>
 

	<tr><td colspan="5">
		
		<b><i>Comit� :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </i></b><?php nom_comite(); ?><br>
		<b><i>Factur� � :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i></b><?php echo $factureA; ?><br>
		<b><i>Description :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i></b><?php echo $description; ?><br><br>
	</td></tr>	
 
	<tr><td>
	<table align="center" border="2" width="100%" bordercolor="black">

	  <tr bgcolor="black">
	    <td align="center"><font color="white"><b> Brasseur  </b></font></td>
	    <td align="center"><font color="white"><b> Nom </b></font></td>
	    <td align="center"><font color="white"><b> Prix ($) </b></font></td>
	    <td align="center"><font color="white"><b> Qt� Inventaire </b></font></td>
	    <td align="center"><font color="white"><b> Qt� Factur�e </b></font></td>
	  </tr>
	
	  <?php load_inventaire_commande(); 

	//On re-passe en param�tre les donn�es que l'on vient de recevoir...
	echo "<input name=\"comiteID\" type=\"hidden\" size=\"7\" value=".$comiteID.">";
	echo "<input name=\"factureA\" type=\"hidden\" size=\"7\" value=".urlencode(serialize($factureA)).">";
	echo "<input name=\"description\" type=\"hidden\" size=\"7\" value=".urlencode(serialize($description)).">";

	?>
	</table>
	</td></tr>
		
	<tr><td colspan="5"><center><input type="submit" value="Passer � l'�tape 3"> <br><hr></center>  </form> </td></tr>			

	
	
 </table>
 

<!-- La commande suivante ins�re le bas de page -->
<?php include("bas_page.inc.php")?>
	