<?php

function verifyAdmin()
{

  $auth = "false"; // Assume user is not authenticated

  if(isset($_SERVER['PHP_AUTH_USER']) && isset($_SERVER['PHP_AUTH_PW'])) 
  {

    // Read the entire file into the variable $file_contents

    $filename = "adminAccess";
    $fp = fopen( $filename, 'r' );
    $file_contents = fread( $fp, filesize( $filename ) );
    fclose( $fp );


    // Place the individual lines from the file contents into an array.

    $lines = explode ( "\n", $file_contents );

    // Split each of the lines into a username and a password pair
    // and attempt to match them to $PHP_AUTH_USER and $PHP_AUTH_PW.

    foreach ( $lines as $line ) 
    {

        list( $username, $password ) = explode( ':', $line );
	 
        if ( $username == $_SERVER['PHP_AUTH_USER'] ) 
	{

           
                $auth = "true";
                break;
        }
     }
   }


  return $auth;


}

   


?>