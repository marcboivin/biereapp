<!-- La commande suivante ins�re le squelette de la page -->

<?php

     include("haut_page.inc.php");



//**************************************************************
// FONCTION DE REMPLISSAGE DU TABLEAu DE L'INVENTAIRE
//***************************************************************
function load_facture_list()
{

  //Connestion � la BD et ouverture de la table "Inventaire"
  
	$connexion = mysql_connect(HOST,USER,PASS);
  	mysql_select_db(DB,$connexion);

	$query = "SELECT nomComite,fichier,date,numFacture FROM factures order by factures.numFacture";
	$result = mysql_query($query,$connexion) or die(mysql_error());
	
	echo "<tr bgcolor=\"black\">
		<td align=\"center\"><b><font color=\"white\">Comit�</font></b></td>
		<td align=\"center\"><b><font color=\"white\"># Facture</font></b></td>
		<td align=\"center\"><b><font color=\"white\">Date</font></b></td>
		<td align=\"center\"><b><font color=\"white\">Fichier</font></b></td>
	    </tr>";

	while ($facture = mysql_fetch_array($result))
 	{
		echo "<tr class=\"trClass\">";
		echo "<td>".$facture[0]."</td><td>".$facture[3]."</td><td>".$facture[2]."</td><td align=\"center\">
				<a href=\"factures/".$facture[1]."\" target=\"_new\"><img src=\"images/acceder.gif\" border=\"0\"></a></td>";
		echo "</tr>";
  	}	

	
  	mysql_free_result($result);
 	mysql_close($connexion);

}
?>



 <table align="center" border="5" width="600">

	<?php 
		load_facture_list(); 
	?>
			
 </table>
 

<!-- La commande suivante ins�re le bas de page -->
<?php include("bas_page.inc.php")?>
	
