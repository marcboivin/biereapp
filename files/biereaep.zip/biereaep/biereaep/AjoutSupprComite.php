<!-- La commande suivante ins�re le squelette de la page -->

<?php

 
     include("authenticateAdmin.inc.php");
     include("haut_page.inc.php");

 //**********************************************************
// FONCTION DE REMPLISSAGE DE LA BOITE DE S�LECTION - Comit�s
//***************************************************************
function load_box_comite()
{

  //Connestion � la BD et ouverture de la table "Comit�s"
  
	$connexion = mysql_connect(HOST,USER,PASS);
  	mysql_select_db(DB,$connexion);

  	$result = mysql_query("SELECT num_auto,nomComite FROM comites order by num_auto",$connexion) or die(mysql_error());

   // Affichage des r�sultats de la requ�te....
  while ($comite = mysql_fetch_array($result))
  {
		echo "<option value=".$comite[0]."\">".$comite[1]."</option>";	
  }

  mysql_free_result($result);
  mysql_close($connexion);

}




$okAdmin = verifyAdmin();
if ($okAdmin == "true")
{

	include("FORM_AjoutSupprComite.php");
}
else
{
	include("erreur.php");

}


?>



<!-- La commande suivante ins�re le bas de page -->
<?php include("bas_page.inc.php")?>
	