<!-- La commande suivante ins�re le squelette de la page -->

<?php include("haut_page.inc.php");




//**************************************************************
// FONCTION DE REMPLISSAGE DE LA BOITE DE S�LECTION - Comit�
//***************************************************************
function load_box_comite()
{

  //Connestion � la BD et ouverture de la table "Brasseurs"
  
	$connexion = mysql_connect(HOST,USER,PASS);
  	mysql_select_db(DB,$connexion);

  	$result = mysql_query("SELECT num_auto,nomComite FROM comites order by nomComite",$connexion) or die(mysql_error());

   // Affichage des r�sultats de la requ�te....
  while ($comite = mysql_fetch_array($result))
  {
		echo "<option value=".$comite[0].">".$comite[1]."</option>";	
  }

  mysql_free_result($result);
  mysql_close($connexion);

}
//***************************************************************


  
?>


 <table align="center" border="0">

	<tr> <td> <form enctype="multipart/form-data" action="factureCommande2.php" method="POST"> </td></tr>
	<tr><td align="center">
		<font size="4"> <b><i>FACTURATION</i></b></font><br>
		<img src="images/facturationEtape1.gif">
	</td></tr>
 

	<tr><td>
		

		<b><i>Comit� :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i></b>
		<select name="comiteID" id="comiteID">
				<?php load_box_comite(); ?>
		 </select> <br><br>
 
			

		<b><i>Factur� � :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i></b><input name="factureA" type="text" size="60" value=""><br><br>
		<b><i>Description (facultatif):&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i></b><input name="description" type="text" size="60" value=""><br><br>
		<center><input type="submit" value="Passer � l'�tape 2"> <br><hr></center>  </form> 			

	</td></tr>
	
 </table>
 

<!-- La commande suivante ins�re le bas de page -->
<?php include("bas_page.inc.php")?>
	